/**
 * File: CompteAbstract.java
 * Created: October 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */
package opBancaires;

import java.util.ArrayList;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public abstract class CompteAbstract {

	// ***************** ATTRIBUTS ***********************
	private static int lastId = 0;

	/**
	 * Numéro identifiant du compte.
	 */
	private int numId;

	/**
	 * Libellé du compte.
	 */
	private String libelle;

	/**
	 * Solde courant du compte. Sa modification ne doit se faire que par
	 * l'intermédiaire des méthodes de gestion prévues à cet effet.
	 */
	private double solde;

	/**
	 * Field <b><code>titulaire</code></b><br>
	 * 
	 * Référence du client titulaire.
	 */
	private Client titulaire;

	/**
	 * Field <b><code>lastIdOperation</code></b><br>
	 * 
	 * Valeur de l'identifiant de la dernière opération effectuée sur ce compte.
	 */
	private int lastIdOperation = 0;

	/**
	 * Field <b><code>historiqueOperations</code></b><br>
	 * 
	 * Historique des opérations effectuées sur ce compte.
	 */
	private ArrayList<Operation> historiqueOperations;

	// ******************* METHODES ABSTRAITES ***********************
	/**
	 * Mise du montant spécifié au crédit du compte.
	 * 
	 * Si le crédit est possible alors le solde est modifié directement, et une
	 * opération de succès est créée.
	 * 
	 * Si le crédit n'est pas possible, alors le solde reste inchangé, et une
	 * opération d'échec est créée.
	 * 
	 * @param montant
	 *            Le montant à créditer.
	 * @return la valeur du novueau solde.
	 * @throws MontantException
	 */
	public abstract double crediter(double montant)
			throws OperationBancaireException;

	/**
	 * Mise du montant spécifié au crédit du compte.
	 * 
	 * Si le crédit est possible alors le solde est modifié directement, et
	 * l'opération placée en paramètre est modifiée en conséquence, avec un
	 * statut de succès.
	 * 
	 * Si le crédit n'est pas possible, alors le solde reste inchangé, et
	 * l'opération placée en paramètre est modifiée en conséquence, avec un
	 * statut d'échec.
	 * 
	 * @param montant
	 * @param op
	 * @return le nouveau solde, après crédit.
	 * @throws OperationBancaireException
	 */
	public abstract double crediter(double montant, Operation op)
			throws OperationBancaireException;

	// ********************** METHODES *******************************

	/**
	 * Mise du montant spécifié au débit du compte.
	 * 
	 * Si le débit est possible alors le solde est modifié directement, et une
	 * opération de succès est créée.
	 * 
	 * Si le débit n'est pas possible, alors le solde reste inchangé, et une
	 * opération d'échec est créée.
	 * 
	 * @param montant
	 *            Le montant à débiter.
	 * @return le nouveau solde, après débit.
	 * @throws OperationBancaireException
	 */
	public double debiter(double montant) throws OperationBancaireException {
		if (montant > this.getSolde()) {
			historiqueOperations.add(new Operation(titulaire, this,
					StatutEnum.KO, NatureOperationEnum.DEBIT, montant));
			throw new OperationBancaireException("Solde insuffisant");
		}
		if (montant < 0) {
			historiqueOperations.add(new Operation(titulaire, this,
					StatutEnum.KO, NatureOperationEnum.DEBIT, montant));
			throw new OperationBancaireException(
					"Débit d'un montant négatif impossible");
		}
		historiqueOperations.add(new Operation(titulaire, this, StatutEnum.OK,
				NatureOperationEnum.DEBIT, montant));
		setSolde(this.getSolde() - montant);
		return this.getSolde();
	}

	/**
	 * Mise du montant spécifié au débit du compte.
	 * 
	 * Si le débit est possible alors le solde est modifié directement, et
	 * l'opération placée en paramètre est modifiée en conséquence, avec un
	 * statut de succès.
	 * 
	 * Si le débit n'est pas possible, alors le solde reste inchangé, et
	 * l'opération placée en paramètre est modifiée en conséquence, avec un
	 * statut d'échec.
	 * 
	 * @param montant
	 * @param op
	 * @return le nouveau solde, après débit.
	 * @throws OperationBancaireException
	 */
	public double debiter(double montant, Operation op)
			throws OperationBancaireException {
		if (montant > this.getSolde()) {
			op.initOperation(titulaire, this, StatutEnum.KO,
					NatureOperationEnum.DEBIT, montant);
			historiqueOperations.add(op);
			throw new OperationBancaireException("Solde insuffisant");
		}
		if (montant < 0) {
			op.initOperation(titulaire, this, StatutEnum.KO,
					NatureOperationEnum.DEBIT, montant);
			historiqueOperations.add(op);
			throw new OperationBancaireException(
					"Débit d'un montant négatif impossible");
		}
		op.initOperation(titulaire, this, StatutEnum.OK,
				NatureOperationEnum.DEBIT, montant);
		historiqueOperations.add(op);
		setSolde(this.getSolde() - montant);
		return this.getSolde();
	}

	/**
	 * Teste si le compte peut être débité du montant précisé en paramètre.
	 * 
	 * @param montant
	 * @return <code>true</code> si le compte peut être débité du montant
	 *         précisé en paramètre.
	 */
	public boolean estDebitableDe(double montant) {
		return (montant <= this.getSolde() && montant > 0);
	}

	/**
	 * Retourne un nouvel identifiant d'opération pour ce compte, et maintien à
	 * jour la valeur du dernier identifiant utilisé.
	 * 
	 * @return un nouvel identifiant d'opération pour ce compte.
	 */
	public int getNewIdOperation() {
		return ++lastIdOperation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.getClass() + " ["
				+ (libelle != null ? "libelle=" + libelle + ", " : "")
				+ "numId=" + numId + ", solde=" + solde + ", "
				+ (titulaire != null ? "titulaire=" + titulaire.getNom() : "")
				+ ", lastIdOperation=" + lastIdOperation
				+ ", historiqueOperations=" + this.toStringOperations() + "]";
	}

	/**
	 * @return a String of historical operations.
	 */
	public String toStringOperations() {
		StringBuilder s = new StringBuilder();
		for (Operation o : historiqueOperations) {
			s.append(o.toString() + "\n");
		}
		return s.toString();
	}

	// ********************* ACCESSEURS ********************************
	/**
	 * @return la valeur du solde courant.
	 */
	public double getSolde() {
		return solde;
	}

	/**
	 * @param solde
	 */
	protected void setSolde(double solde) {
		this.solde = solde;
	}

	/**
	 * @return the numId
	 */
	public int getNumId() {
		return numId;
	}

	/**
	 * @param numId
	 *            the numId to set
	 */
	public void setNumId(int numId) {
		this.numId = numId;
	}

	/**
	 * @return the libelle
	 */
	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param libelle
	 *            the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	/**
	 * @return int - Returns the lastId.
	 */
	public static int getLastId() {
		return lastId;
	}

	/**
	 * @return Client - Returns the titulaire.
	 */
	public Client getTitulaire() {
		return titulaire;
	}

	/**
	 * @return int - Returns the lastIdOperation.
	 */
	public int getLastIdOperation() {
		return lastIdOperation;
	}

	/**
	 * @return ArrayList<Operation> - Returns the historiqueOperations.
	 */
	public ArrayList<Operation> getHistoriqueOperations() {
		return historiqueOperations;
	}

	// ***************** CONSTRUCTEURS *********************************
	/**
	 * Constructeur.
	 * 
	 * @param titulaire
	 */
	protected CompteAbstract(Client titulaire) {
		this.numId = ++CompteAbstract.lastId;
		this.titulaire = titulaire;
		titulaire.addCompte(this);
		historiqueOperations = new ArrayList<Operation>();
	}

}
