/**
* File:		CompteNonAutoriseException.java
* @author:	Jean-Philippe Prost
* Email:	Prost@lirmm.fr
* Creation:	23 oct. 2012
* @version:	1.0
* Project:	pooJavaTDs
* 
* Comments:
*
*/

package opBancaires;

/**
 * Type <b><code>CompteNonAutoriseException</code></b><br>
 * 
 */
public class CompteNonAutoriseException extends Exception {

}

// EOF CompteNonAutoriseException.java
