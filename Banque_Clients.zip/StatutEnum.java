/**
 * File:		StatutEnum.java
 * @author:	Jean-Philippe Prost
 * Email:	Prost@lirmm.fr
 * Creation:	22 oct. 2012
 * @version:	1.0
 * Project:	pooJavaTDs
 * 
 * Comments:
 *
 */

package opBancaires;

/**
 * Type <b><code>StatutEnum</code></b><br>
 * 
 * Domaine de valeur pour le statut d'une opération, ou d'un ordre
 * de virement.
 */
public enum StatutEnum {
	OK, KO, ATTENTE
}

// EOF StatutEnum.java
