/**
 * File: Client.java
 * Created: 17 Oct 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */
package opBancaires;

import java.util.ArrayList;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public class Client {
	// ******************* ATTRIBUTS ***********************
	/**
	 * Variable de classe. Valeur du dernier identifiant de client utilisé.
	 */
	private static int lastId = 0;

	/**
	 * Numéro identifiant du client.
	 */
	private int numId;

	/**
	 * Nom du client.
	 */
	private String nom;

	/**
	 * Field <b><code>comptes</code></b><br>
	 * 
	 * Listes des comptes dont le client est titulaire.
	 */
	private ArrayList<CompteAbstract> comptes;

	/**
	 * Field <b><code>attache</code></b><br>
	 * 
	 * Référence de l'attaché client.
	 */
	private Attache attache;

	// ********************* ACCESSEURS ********************************
	/**
	 * @return the numId
	 */
	public int getNumId() {
		return numId;
	}

	/**
	 * @param numId
	 *            the numId to set
	 */
	public void setNumId(int numId) {
		this.numId = numId;
	}

	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom
	 *            the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return the comptes
	 */
	public ArrayList<CompteAbstract> getComptes() {
		return comptes;
	}

	/**
	 * @return Attache - Returns the attache.
	 */
	public Attache getAttache() {
		return attache;
	}

	/**
	 * @param attache
	 *            Attache - The attache to set.
	 */
	public void setAttache(Attache attache) {
		this.attache = attache;
	}

	/**
	 * @return int - Returns the lastId.
	 */
	public static int getLastId() {
		return lastId;
	}

	// ********************* METHODES ********************************
	/**
	 * Ajoute un compte dont le client est titulaire.
	 * 
	 * @param compte
	 */
	public void addCompte(CompteAbstract compte) {
		comptes.add(compte);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Client [numId=" + numId + ", nom=" + nom + ", comptes="
				+ (comptes == null ? "" : comptes) + ", attache="
				+ (attache == null ? "" : attache.getNom()) + "]";
	}

	// ********************* CONSTRUCTEURS ********************************

	/**
	 * Constructeur.
	 * 
	 * @param nom
	 * @param attache
	 */
	public Client(String nom, Attache attache) {
		this.numId = ++Client.lastId;
		this.nom = nom;
		this.attache = attache;
		attache.getClients().add(this);
		comptes = new ArrayList<CompteAbstract>();
	}
}
