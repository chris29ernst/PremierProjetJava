/**
 * File:		Attache.java
 * @author:	Jean-Philippe Prost
 * Email:	Prost@lirmm.fr
 * Creation:	22 oct. 2012
 * @version:	1.0
 * Project:	pooJavaTDs
 * 
 * Comments:
 *
 */

package opBancaires;

import java.util.ArrayList;

/**
 * Type <b><code>Attache</code></b><br>
 * 
 */
public class Attache {

	// ----------------------------------------------------------------//
	// Fields declarations
	// ----------------------------------------------------------------//
	/**
	 * Nom de l'attaché.
	 */
	private String nom;

	/**
	 * Liste de clients gérés par l'attaché.
	 */
	private ArrayList<Client> clients;

	/**
	 * Liste des opérations en attente de validation manuelle par l'attaché.
	 */
	private ArrayList<Operation> opEnAttente;

	// ----------------------------------------------------------------//
	// Methods definitions
	// ----------------------------------------------------------------//
	/**
	 * Enregistre l'operation dans la file d'attente de l'attaché du client.
	 * 
	 * @param op
	 */
	public void enregistrerOpEnAttente(Operation op) {
		opEnAttente.add(op);
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Getters and Setters definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	/**
	 * @return String - Returns the nom.
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom
	 *            String - The nom to set.
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return ArrayList<Client> - Returns the clients.
	 */
	public ArrayList<Client> getClients() {
		return clients;
	}

	/**
	 * @return the opEnAttente
	 */
	public ArrayList<Operation> getOpEnAttente() {
		return opEnAttente;
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Overriden/Delegate methods definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Attache [" + (nom != null ? "nom=" + nom + ", " : "")
				+ (clients != null ? "clients=" + clients + ", " : "")
				+ (opEnAttente != null ? "opEnAttente=" + opEnAttente : "")
				+ "]";
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Constructor(s)
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	/**
	 * @param nom
	 *            Constructor.
	 */
	public Attache(String nom) {
		super();
		this.nom = nom;
		clients = new ArrayList<Client>();
		opEnAttente = new ArrayList<Operation>();
	}

}

// EOF Attache.java
