/**
 * File:		Operation.java
 * @author:	Jean-Philippe Prost
 * Email:	Prost@lirmm.fr
 * Creation:	22 oct. 2012
 * @version:	1.0
 * Project:	pooJavaTDs
 * 
 * Comments:
 *
 */

package opBancaires;

import java.util.Date;

public class Operation {

	// ----------------------------------------------------------------//
	// Fields declarations
	// ----------------------------------------------------------------//
	/**
	 * Numéro identifiant de l'opération (pour un compte donné).
	 */
	private int numId;
	/**
	 * Client titulaire du compte concerné par l'opération.
	 */
	private Client client;
	/**
	 * Compte concerné par l'opération.
	 */
	private CompteAbstract compte;
	/**
	 * Statut de l'opération (OK, KO, ou ATTENTE).
	 */
	private StatutEnum statut;
	/**
	 * Nature de l'opération (DEBIT ou CREDIT).
	 */
	private NatureOperationEnum nature;
	/**
	 * Montant de l'opération.
	 */
	private double montant;
	/**
	 * Date de prise d'effet de l'opération.
	 */
	private Date dateEffet;

	// ----------------------------------------------------------------//
	// Methods definitions
	// ----------------------------------------------------------------//

	/**
	 * Initialise un objet <code>Operation</code> pré-existant avec les valeurs
	 * spécifiées en paramètres.
	 * 
	 * @param client
	 * @param compte
	 * @param statut
	 * @param nature
	 * @param montant
	 */
	public void initOperation(Client client, CompteAbstract compte,
			StatutEnum statut, NatureOperationEnum nature, double montant) {
		this.client = client;
		this.compte = compte;
		numId = compte.getNewIdOperation();
		this.statut = statut;
		this.nature = nature;
		this.montant = montant;
		dateEffet = new Date();
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Overriden/Delegate methods definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Operation [numId=" + numId + ", client="
				+ (client == null ? "" : client.getNom()) + ", compte="
				+ (compte == null ? "" : compte.getNumId()) + ", statut="
				+ statut + ", nature=" + nature + ", montant=" + montant
				+ ", dateEffet=" + (dateEffet == null ? "" : dateEffet) + "]";
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Getters and Setters definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

	/**
	 * @return Client - Returns the client.
	 */
	public Client getClient() {
		return client;
	}

	/**
	 * @param client
	 *            Client - The client to set.
	 */
	public void setClient(Client client) {
		this.client = client;
	}

	/**
	 * @return CompteAbstract - Returns the compte.
	 */
	public CompteAbstract getCompte() {
		return compte;
	}

	/**
	 * @param compte
	 *            CompteAbstract - The compte to set.
	 */
	public void setCompte(CompteAbstract compte) {
		this.compte = compte;
	}

	/**
	 * @return StatutEnum - Returns the statut.
	 */
	public StatutEnum getStatut() {
		return statut;
	}

	/**
	 * @param statut
	 *            StatutEnum - The statut to set.
	 */
	public void setStatut(StatutEnum statut) {
		this.statut = statut;
	}

	/**
	 * @return NatureOperationEnum - Returns the nature.
	 */
	public NatureOperationEnum getNature() {
		return nature;
	}

	/**
	 * @param nature
	 *            NatureOperationEnum - The nature to set.
	 */
	public void setNature(NatureOperationEnum nature) {
		this.nature = nature;
	}

	/**
	 * @return double - Returns the montant.
	 */
	public double getMontant() {
		return montant;
	}

	/**
	 * @param montant
	 *            double - The montant to set.
	 */
	public void setMontant(double montant) {
		this.montant = montant;
	}

	/**
	 * @return Date - Returns the dateEffet.
	 */
	public Date getDateEffet() {
		return dateEffet;
	}

	/**
	 * @param dateEffet
	 *            Date - The dateEffet to set.
	 */
	public void setDateEffet(Date dateEffet) {
		this.dateEffet = dateEffet;
	}

	/**
	 * @return int - Returns the numId.
	 */
	public int getNumId() {
		return numId;
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Constructor(s)
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	/**
	 * Constructor.
	 * 
	 * Attention, ce constructeur est à utiliser avec la plus grande des
	 * prudences : il est, normalement, uniquement destiné à la manipulation des
	 * opérations en ATTENTE.
	 * 
	 * Seuls le champ <code>statut</code> est instancié ; tous les autres
	 * prennent une valeur nulle (0 ou <code>null</code>, selon que le champ est
	 * d'un type primitif ou référence).
	 * 
	 */
	public Operation() {
		this.client = null;
		this.compte = null;
		numId = 0;
		this.statut = StatutEnum.ATTENTE;
		this.nature = null;
		this.montant = 0;
		dateEffet = null;
	}

	/**
	 * Constructor.
	 * 
	 * @param client
	 * @param compte
	 * @param statut
	 * @param nature
	 * @param montant
	 */
	public Operation(Client client, CompteAbstract compte, StatutEnum statut,
			NatureOperationEnum nature, double montant) {
		super();
		this.client = client;
		this.compte = compte;
		numId = compte.getNewIdOperation();
		this.statut = statut;
		this.nature = nature;
		this.montant = montant;
		dateEffet = new Date();
	}
}

// EOF Operation.java
