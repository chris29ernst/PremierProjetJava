/**
 * File: Banque.java
 * Created: 17 Oct 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */

package opBancaires;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public class Banque {

	// ********************* MAIN ********************************
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Attache attache1 = new Attache("Attache1");
		Attache attache2 = new Attache("Attache2");
		Client prost = new Client("Prost", attache1);
		Client bougeret = new Client("Bougeret", attache2);

		CompteCourant courantProst = new CompteCourant(prost), courantBougeret = new CompteCourant(
				bougeret);
		CompteEpargne epargneProst = new CompteEpargne(prost, 700);

		/* CAS */
		String texteDescriptifTest = "** Test 1 : création clients et comptes\n";
		System.out.println(texteDescriptifTest + prost + "\n" + bougeret);

		/* CAS */
		texteDescriptifTest = "\n**Test 2 : crédit initial : 2000€ sur Prost courant, et 33 sur Prost epargne\n";
		try {
			prost.getComptes().get(0).crediter(2000);
			epargneProst.crediter(33);
		} catch (OperationBancaireException e) {
			e.printStackTrace();
		}
		System.out.println(texteDescriptifTest
				+ prost.getComptes().get(0).getHistoriqueOperations()
						.toString());
		System.out.println(prost.getComptes().get(1).getHistoriqueOperations()
				.toString());
		System.out.println(" Comptes :\n" + prost.getComptes());

		/* CAS */
		texteDescriptifTest = "\n**Test 3 : opération débit OK\n";
		try {
			prost.getComptes().get(0).debiter(500);
		} catch (OperationBancaireException e) {
			e.printStackTrace();
		}
		System.out.println(texteDescriptifTest
				+ prost.getComptes().get(0).toString());

		/* CAS */
		texteDescriptifTest = "\n**Test 4 : opération débit KO : exception\n"
				+ " (ATTENTION ! L'AFFICHAGE DE LA TRACE DE L'EXCEPTION EST DESYNCHRONISE (System.err tamponné)...)\n";
		try {
			prost.getComptes().get(0).debiter(2500);
		} catch (OperationBancaireException e) {
			System.err.print("\nException levée : ");
			e.printStackTrace();
		} finally {
			System.out.println(texteDescriptifTest
					+ prost.getComptes().get(0).toString());
		}

		/* CAS */
		texteDescriptifTest = "\n**Test 5 : opération débit OK, avec debiter(montant,operation)\n";
		Operation op = new Operation();
		try {
			prost.getComptes().get(0).debiter(123, op);
		} catch (OperationBancaireException e) {
			e.printStackTrace();
		}
		System.out.print(texteDescriptifTest);
		System.out.println(op);
		System.out.println(prost.getComptes().get(0).toString());

		/* CAS */
		texteDescriptifTest = "\n**Test 6 : ordre de virement OK : 666 de Prost courant vers Prost epargne\n";

		try {
			OrdreVirement ordre = new OrdreVirement(prost, courantProst,
					epargneProst, 666);
			boolean estPasse = ordre.passer();
			System.out.println(texteDescriptifTest + " Ordre (" + estPasse
					+ ") :\n" + ordre);
			System.out.println(" Comptes :\n" + courantProst + "\n"
					+ epargneProst);
		} catch (CompteNonAutoriseException e) {
			e.printStackTrace();
		}

		/* CAS */
		texteDescriptifTest = "\n**Test 7 : ordre de virement KO, sans mise en attente (pas d'exception)"
				+ " : 100 000 de Prost courant vers Prost epargne\n";

		try {
			OrdreVirement ordre = new OrdreVirement(prost, courantProst,
					epargneProst, 10e+4);
			boolean estPasse = ordre.passer();
			System.out.println(texteDescriptifTest + " Ordre (" + estPasse
					+ ") :\n" + ordre);
			System.out.println(" Comptes :\n" + courantProst + "\n"
					+ epargneProst);
		} catch (CompteNonAutoriseException e) {
			e.printStackTrace();
		}
		System.out.println(" File d'attente attache ("
				+ prost.getAttache().getNom() + ") :");
		System.out.println(prost.getAttache().getOpEnAttente());

		/* CAS */
		texteDescriptifTest = "\n**Test 8 : ordre de virement KO, avec mise en attente (exception levée)"
				+ " : 100 de Prost courant vers Prost epargne\n";

		try {
			OrdreVirement ordre = new OrdreVirement(prost, courantProst,
					epargneProst, 100);
			boolean estPasse = ordre.passer();
			System.out.println(texteDescriptifTest + " Ordre (" + estPasse
					+ ") :\n" + ordre);
			System.out.println(" Comptes :\n" + courantProst + "\n"
					+ epargneProst);
		} catch (CompteNonAutoriseException e) {
			e.printStackTrace();
		}
		System.out.println(" File d'attente attache ("
				+ prost.getAttache().getNom() + ") :");
		System.out.println(prost.getAttache().getOpEnAttente());
	}
}
