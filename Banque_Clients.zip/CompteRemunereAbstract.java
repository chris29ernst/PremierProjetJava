/**
 * File: CompteRemunereAbstract.java
 * Created: 17 Oct 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */

package opBancaires;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public abstract class CompteRemunereAbstract extends CompteAbstract {

	// ******************* ATTRIBUTS ***********************
	/**
	 * Taux de rémunération.
	 */
	private double taux;
	/**
	 * Montant du plafond associé au compte.
	 * 
	 * Le plafond est le solde maximum autorisé sur le compte.
	 */
	private double plafond;

	// ********************* ACCESSEURS ********************************

	/**
	 * @return the taux
	 */
	public double getTaux() {
		return taux;
	}

	/**
	 * @param taux
	 *            the taux to set
	 */
	public void setTaux(double taux) {
		this.taux = taux;
	}

	/**
	 * @return the plafond
	 */
	public double getPlafond() {
		return plafond;
	}

	/**
	 * @param plafond
	 *            the plafond to set
	 */
	public void setPlafond(double plafond) {
		this.plafond = plafond;
	}

	// ********************* METHODES ********************************

	/*
	 * (non-Javadoc)
	 * 
	 * @see opBancaires.CompteAbstract#crediter(double)
	 */
	@Override
	public double crediter(double montant) throws OperationBancaireException {
		if (montant < 0)
			throw new OperationBancaireException(
					"Crédit d'un montant négatif impossible");
		if (montant + this.getSolde() > this.plafond)
			throw new OperationBancaireException(
					"Crédit impossible : solde plafonné");
		this.setSolde(this.getSolde() + montant);
		return this.getSolde();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CompteRemunereAbstract [plafond="
				+ plafond
				+ ", taux="
				+ taux
				+ ", "
				+ (super.toString() != null ? "détail=" + super.toString() : "")
				+ "]";
	}

	// ********************* CONSTRUCTEURS ********************************
	/**
	 * Constructor.
	 * 
	 * @param titulaire
	 */
	protected CompteRemunereAbstract(Client titulaire) {
		super(titulaire);
		taux = 0;
	}

}
