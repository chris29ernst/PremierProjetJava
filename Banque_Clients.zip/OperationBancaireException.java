/**
 * File: OperationBancaireException.java
 * Created: 17 Oct 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */

// ******************* ATTRIBUTS ***********************
// ********************* ACCESSEURS ********************************
// ********************* METHODES ********************************
// ********************* CONSTRUCTEURS ********************************

package opBancaires;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public class OperationBancaireException extends Exception {

	/**
	 * @param msg
	 *            Le message qui sera affiché si l'exception est levée.
	 */
	public OperationBancaireException(String msg) {
		super(msg);
	}

	public OperationBancaireException() {
		super();
	}
}
