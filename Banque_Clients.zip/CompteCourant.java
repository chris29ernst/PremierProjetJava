/**
 * File: CompteCourant.java
 * Created: 17 Oct 2012
 * Author: Jean-Philippe.Prost@univ-montp2.fr
 * Description:
 */

package opBancaires;

/**
 * @author <Jean-Philippe.Prost@LIRMM.fr> Creation 17 Oct 2012
 * 
 */
public class CompteCourant extends CompteAbstract {

	// ********************* METHODES ********************************
	/*
	 * (non-Javadoc)
	 * 
	 * @see opBancaires.CompteAbstract#crediter(double)
	 */
	@Override
	public double crediter(double montant) throws OperationBancaireException {
		if (montant < 0) {
			this.getHistoriqueOperations().add(
					new Operation(this.getTitulaire(), this, StatutEnum.KO,
							NatureOperationEnum.CREDIT, montant));
			throw new OperationBancaireException(
					"Crédit d'un montant négatif impossible");
		}
		this.getHistoriqueOperations().add(
				new Operation(this.getTitulaire(), this, StatutEnum.OK,
						NatureOperationEnum.CREDIT, montant));
		this.setSolde(this.getSolde() + montant);
		return this.getSolde();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see opBancaires.CompteAbstract#crediter(double, opBancaires.Operation)
	 */
	@Override
	public double crediter(double montant, Operation op)
			throws OperationBancaireException {
		if (montant < 0) {
			op.initOperation(getTitulaire(), this, StatutEnum.KO,
					NatureOperationEnum.CREDIT, montant);
			this.getHistoriqueOperations().add(op);
			throw new OperationBancaireException(
					"Crédit d'un montant négatif impossible");
		}

		op.initOperation(this.getTitulaire(), this, StatutEnum.OK,
				NatureOperationEnum.CREDIT, montant);
		this.getHistoriqueOperations().add(op);
		this.setSolde(this.getSolde() + montant);
		return this.getSolde();
	}

	// ********************* CONSTRUCTEURS ********************************
	/**
	 * Constructeur.
	 * 
	 * @param titulaire
	 */
	public CompteCourant(Client titulaire) {
		super(titulaire);
	}

}
