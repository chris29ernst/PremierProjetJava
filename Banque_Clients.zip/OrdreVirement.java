/**
 * File:		OrdreVirement.java
 * @author:	Jean-Philippe Prost
 * Email:	Prost@lirmm.fr
 * Creation:	23 oct. 2012
 * @version:	1.0
 * Project:	pooJavaTDs
 * 
 * Comments:
 *
 */

package opBancaires;

/**
 * Type <b><code>OrdreVirement</code></b><br>
 * 
 */
public class OrdreVirement {

	// ----------------------------------------------------------------//
	// Fields declarations
	// ----------------------------------------------------------------//
	/**
	 * Référence sur le donneur d'ordre.
	 */
	private Client donneurOrdre;

	/**
	 * Référence sur le compte origine/destination.
	 */
	private CompteAbstract origine, destination;

	/**
	 * Montant de la transaction.
	 */
	private double montant;

	// ----------------------------------------------------------------//
	// Methods definitions
	// ----------------------------------------------------------------//

	/**
	 * Passe un ordre de virement.
	 * 
	 * En premier lieu, le compte origine est testé pour déterminer si le débit
	 * du montant à virer est possible (sans créer d'opération). Si le débit est
	 * impossible, alors le virement lui-même est impossible (on suppose qu'on
	 * ne peut effectuer de virement que si on dispose effectivement de la somme
	 * à virer).
	 * 
	 * Si le débit est possible, alors une tentative de crédit est effectuée,
	 * avec création d'opération ; si la tentative échoue, alors deux opérations
	 * en ATTENTE sont créées, qui sont envoyées à l'attaché client pour
	 * validation manuelle ; si la tentative réussit, alors l'opération est
	 * effective, et on effectue le débit correspondant. Noter qu'à ce stade le
	 * débit est forcément possible...
	 * 
	 * @return un booléen, indiquant si l'ordre a bien été passé (
	 *         <code>true</code>).
	 * 
	 */
	public boolean passer() {
		Operation opDebit = new Operation(), opCredit = new Operation();

		if (!origine.estDebitableDe(montant))
			return false;

		/*
		 * On commence par tester si le débit est possible (sans créer
		 * d'opération). S'il est impossible, alors le virement lui-même est
		 * impossible (on suppose qu'on ne peut effectuer de virement que si on
		 * dispose effectivement de la somme à virer).
		 * 
		 * Si le débit est possible, alors on fait une tentative de crédit, avec
		 * création d'opération ; si la tentative échoue, alors on crée deux
		 * opérations en ATTENTE, qui sont envoyées à l'attaché pour validation
		 * manuelle ; si la tentative réussit, alors l'opération est effective,
		 * et on effectue le débit correspondant. Noter qu'à ce stade le débit
		 * est forcément possible...
		 */
		try {
			destination.crediter(montant, opCredit);
			opCredit.setStatut(StatutEnum.OK);
			try {
				origine.debiter(montant);
			} catch (OperationBancaireException e) {
				/*
				 * NOTE ! Cette erreur ne devrait jamais arriver, puisque la
				 * possibilité de débit a déjà été testée plus haut...
				 */
				e.printStackTrace();
				return false;
			}
		} catch (OperationBancaireException e) {
			System.err.println("Exception levée :" + e.getStackTrace());
			opDebit.initOperation(origine.getTitulaire(), origine,
					StatutEnum.ATTENTE, NatureOperationEnum.DEBIT, montant);
			opCredit.setStatut(StatutEnum.ATTENTE);
			donneurOrdre.getAttache().getOpEnAttente().add(opDebit);
			donneurOrdre.getAttache().enregistrerOpEnAttente(opCredit);
		}
		return true;
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Overriden/Delegate methods definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrdreVirement ["
				+ (donneurOrdre != null ? "donneurOrdre="
						+ donneurOrdre.getNom() + ", " : "")
				+ "montant="
				+ montant
				+ ", "
				+ (origine != null ? "origine=" + origine.getNumId() + ", "
						: "")
				+ (destination != null ? "destination="
						+ destination.getNumId() : "") + "]";
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Getters and Setters definitions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

	/**
	 * @return the origine
	 */
	public CompteAbstract getOrigine() {
		return origine;
	}

	/**
	 * @param origine
	 *            the origine to set
	 */
	public void setOrigine(CompteAbstract origine) {
		this.origine = origine;
	}

	/**
	 * @return the destination
	 */
	public CompteAbstract getDestination() {
		return destination;
	}

	/**
	 * @param destination
	 *            the destination to set
	 */
	public void setDestination(CompteAbstract destination) {
		this.destination = destination;
	}

	/**
	 * @return the montant
	 */
	public double getMontant() {
		return montant;
	}

	/**
	 * @param montant
	 *            the montant to set
	 */
	public void setMontant(double montant) {
		this.montant = montant;
	}

	/**
	 * @return the donneurOrdre
	 */
	public Client getDonneurOrdre() {
		return donneurOrdre;
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	// Constructor(s)
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
	/**
	 * @param donneurOrdre
	 * @param origine
	 * @param destination
	 * @param montant
	 *            Constructor.
	 */
	public OrdreVirement(Client donneurOrdre, CompteAbstract origine,
			CompteAbstract destination, double montant)
			throws CompteNonAutoriseException {
		if (!origine.getTitulaire().equals(donneurOrdre)
				|| !destination.getTitulaire().equals(donneurOrdre))
			throw new CompteNonAutoriseException();
		this.donneurOrdre = donneurOrdre;
		this.origine = origine;
		this.destination = destination;
		this.montant = montant;
	}
}

// EOF OrdreVirement.java
