/**
 * File:		NatureOperationEnum.java
 * @author:	Jean-Philippe Prost
 * Email:	Prost@lirmm.fr
 * Creation:	22 oct. 2012
 * @version:	1.0
 * Project:	pooJavaTDs
 * 
 * Comments:
 *
 */

package opBancaires;

/**
 * Type <b><code>NatureOperationEnum</code></b><br>
 * 
 * Domaine de valeur pour la nature d'une opération.
 */
public enum NatureOperationEnum {
	DEBIT, CREDIT
}

// EOF NatureOperationEnum.java
